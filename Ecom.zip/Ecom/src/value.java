import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class value implements Writable{
	Text amt, month, tid, category, product, city, state, payment;
	
	public value(){
		this.amt = new Text();
	}
	public value(Text amt){
		this.amt = amt;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		amt.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		amt.write(arg0);
	}
	
	public void setAmt(Text amt){
		this.amt=amt;
	}

	public Double getAmt(){
		return Double.parseDouble(amt.toString());
	}

	public void settid(Text tid){
		this.tid=tid;
	}
	
	public String gettid(){
		return tid.toString();
	}
	
	public void setmonth(Text month){
		this.month=month;
	}
	
	public String getmonth(){
		return month.toString();
	}
	
	public void setcategory(Text category){
		this.category=category;
	}
	
	public String getcategory(){
		return category.toString();
	}
	
	public void setproduct(Text product){
		this.product=product;
	}
	
	public String getproduct(){
		return product.toString();
	}
	
	public void setcity(Text city){
		this.city=city;
	}
	
	public String getcity(){
		return city.toString();
	}
	
	public void setstate(Text state){
		this.state=state;
	}
	
	public String getstate(){
		return state.toString();
	}
	
	public void setpayment(Text payment){
		this.payment=payment;
	}
	
	public String getpayment(){
		return payment.toString();
	}
}
