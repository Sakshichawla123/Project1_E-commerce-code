import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class reducer5 extends Reducer<Text, DoubleWritable, Text, DoubleWritable>{
    public void reduce(Text inpk, Iterable<DoubleWritable> inpv, Context c) throws IOException, InterruptedException{
    	     	   for(DoubleWritable x: inpv)
    	    	    		   c.write(inpk, new DoubleWritable(x.get()));
       }
   }
