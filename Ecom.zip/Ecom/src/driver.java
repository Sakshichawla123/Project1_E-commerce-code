import java.io.IOException;
import java.net.URI;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class driver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Scanner src = new Scanner(System.in);
		System.out.println("Enter your task");
		int task = src.nextInt();
		Configuration conf = new Configuration();
		Job j = new Job(conf, "Output");
		FileSystem hdfs = FileSystem.get(conf);
		switch(task){
		case 1:
			//Configuration conf = new Configuration();
			System.out.println("Enter the minimum value");
			int amt = src.nextInt();
			//conf.setInt("Amount", amt);
			j.getConfiguration().setInt("Amount", amt);
			//FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper1.class);
			j.setNumReduceTasks(0);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(DoubleWritable.class);
			j.setInputFormatClass(inputformat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
		
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/hduser/InputFormat_Trans1");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
		
			System.exit(j.waitForCompletion(true)?0:1);
		break;
		case 2:
			//Configuration conf1 = new Configuration();
			System.out.println("Enter the minimum value");
			int lamt = src.nextInt();
			System.out.println("Enter the minimum value");
			int uamt = src.nextInt();
			j.getConfiguration().setInt("Lower", lamt);;
			j.getConfiguration().setInt("Upper", uamt);
			//Job j1 = new Job(conf1, "Output");
			//FileSystem hdfs1 = FileSystem.get(conf1);
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper2.class);
			j.setReducerClass(reducer2.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(inputformat.class);
			
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			
			Path newpath1 = new Path(args[1]);
			if(hdfs.exists(newpath1)){
				hdfs.delete(newpath1,true);
			}
			Path localfilepath1 = new Path("/home/hduser/InputFormat_Trans2");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath1, localfilepath1);
			}
			
			System.exit(j.waitForCompletion(true)?0:1);	
		break;
		case 3:
			//Configuration conf2 = new Configuration();
			//FileSystem hdfs2 = FileSystem.get(conf2);
			System.out.println("Enter the user id");
			int uid = src.nextInt();
			j.getConfiguration().setInt("User id", uid);
			//conf.setInt("User id", uid);
			//Job j = new Job(conf2, "Output");
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper3.class);
			j.setReducerClass(reducer3.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(DoubleWritable.class);
			j.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));

			Path newpath2 = new Path(args[1]);
			if(hdfs.exists(newpath2)){
				hdfs.delete(newpath2,true);
			}
			
			Path localfilepath2 = new Path("/home/hduser/InputFormat_Trans3");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath2, localfilepath2);
			}
				System.exit(j.waitForCompletion(true)?0:1);
		break;
		case 4:
			//Configuration conf3 = new Configuration();
			//FileSystem hdfs3 = FileSystem.get(conf3);
			j.getConfiguration().setInt("Month", 1);
			//conf.setInt("Month", 1);
			//Job j3 = new Job(conf3, "Output");
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper4.class);
			j.setReducerClass(reducer4.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(DoubleWritable.class);
			j.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));

			Path newpath3 = new Path(args[1]);
			if(hdfs.exists(newpath3)){
				hdfs.delete(newpath3,true);
			}
			
			Path localfilepath3 = new Path("/home/hduser/InputFormat_Trans4");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath3, localfilepath3);
			}
				System.exit(j.waitForCompletion(true)?0:1);
		break;
		case 5:
			//Configuration conf4 = new Configuration();
			//FileSystem hdfs4 = FileSystem.get(conf4);
			j.getConfiguration().setInt("Partitioner", 12);
			//conf.setInt("Partitioner", 12);
			//Job j4 = new Job(conf4, "Output");
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper5.class);
			j.setReducerClass(reducer5.class);
			j.setPartitionerClass(partitioner5.class);
			j.setNumReduceTasks(12);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(DoubleWritable.class);
			j.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));

			Path newpath4 = new Path(args[1]);
			if(hdfs.exists(newpath4)){
				hdfs.delete(newpath4,true);
			}
			
			Path localfilepath4 = new Path("/home/hduser/InputFormat_Trans5");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath4, localfilepath4);
			}
				System.exit(j.waitForCompletion(true)?0:1);
		break;
		case 6:
			//Configuration conf5 = new Configuration();
			//FileSystem hdfs5 = FileSystem.get(conf5);
			j.getConfiguration().setInt("dummy", 1);
			//conf.setInt("dummy", 1);
			//Job j5 = new Job(conf5, "Output");
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper6.class);
			j.setReducerClass(reducer6.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(DoubleWritable.class);
			j.setMapOutputValueClass(Text.class);
			j.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));

			Path newpath5 = new Path(args[1]);
			if(hdfs.exists(newpath5)){
				hdfs.delete(newpath5,true);
			}
			
			Path localfilepath5 = new Path("/home/hduser/InputFormat_Trans6");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath5, localfilepath5);
			}
				System.exit(j.waitForCompletion(true)?0:1);
		break;
		
			}

		}
	}
